<?php

return [
    'statuses' => [
        'draft'     => 'Draft',
        'pending'   => 'Pending',
        'published' => 'Published',
    ],
];
