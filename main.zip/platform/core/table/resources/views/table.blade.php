@extends('core/base::layouts.master')
@section('content')
    @include('core/table::base-table')
@stop
