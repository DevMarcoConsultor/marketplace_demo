<div class="input-group">
    {!! $content !!}
    <span class="input-group-append">
        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
    </span>
</div>